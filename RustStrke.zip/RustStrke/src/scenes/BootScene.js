class BootScene extends Phaser.Scene {
    constructor() {
        super('BootScene');
    }

    preload() {
        console.log('Boot Scene started');
    }

    create() {
        // Once the boot scene is done
        this.scene.start('Preloader');
    }
}

export default BootScene;
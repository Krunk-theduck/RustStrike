class StartScreen extends Phaser.Scene {
    constructor() {
      super('StartScreen');
      this.roomBrowserVisible = false;
    }
    
    preload() {
    }
    
    create() {
      this.add.image(this.cameras.main.width / 2, this.cameras.main.height / 2, 'bg')
        .setOrigin(0.5)
        .setScale(0.6);
  
      let title = this.add.image(this.cameras.main.width / 2, 200, 'logo').setOrigin(0.5);
      title.setScale(0.5);
      
      // Main menu buttons
      this.mainMenu = this.add.container(0, 0);
      
      let playText = this.add.text(this.cameras.main.width / 2, 400, 'PLAY', { 
        font: '28px Arial', 
        fill: '#ffffff',
        stroke: '#333333',
        strokeThickness: 4
      }).setOrigin(0.5).setInteractive();
      
      let settingsText = this.add.text(this.cameras.main.width / 2, 460, 'SETTINGS', { 
        font: '24px Arial', 
        fill: '#aaaaaa',
        stroke: '#333333',
        strokeThickness: 3 
      }).setOrigin(0.5).setInteractive();
      
      let exitText = this.add.text(this.cameras.main.width / 2, 520, 'EXIT', { 
        font: '24px Arial', 
        fill: '#aaaaaa',
        stroke: '#333333',
        strokeThickness: 3 
      }).setOrigin(0.5).setInteractive();
      
      this.mainMenu.add([playText, settingsText, exitText]);
      
      // Set up button interactions
      [playText, settingsText, exitText].forEach(text => {
        text.on('pointerover', () => text.setStyle({ fill: '#FFD700' }));
        text.on('pointerout', () => text.setStyle({ 
          fill: text.text === 'PLAY' ? '#ffffff' : '#aaaaaa',
          stroke: '#333333',
          strokeThickness: text.text === 'PLAY' ? 4 : 3
        }));
      });
      
      // Create the room browser (initially hidden)
      this.createRoomBrowser();
      
      // Button handlers
      playText.on('pointerdown', () => this.toggleRoomBrowser(true));
      settingsText.on('pointerdown', () => console.log('Open settings menu'));
      exitText.on('pointerdown', () => console.log('Exit game'));
      
      // Back button in room browser
      this.backButton.on('pointerdown', () => this.toggleRoomBrowser(false));
    }
    
    createRoomBrowser() {
      // Container for room browser
      this.roomBrowser = this.add.container(0, 0);
      this.roomBrowser.visible = false;
      
      // Darken background
      let darkOverlay = this.add.rectangle(
        this.cameras.main.width / 2,
        this.cameras.main.height / 2,
        this.cameras.main.width,
        this.cameras.main.height,
        0x000000, 0.7
      );

    let panelBg = this.add.rectangle(
          this.cameras.main.width / 2,
          this.cameras.main.height / 2,
          650, 550, // Increased size for more space
          0x333333
        ).setStrokeStyle(4, 0x888888);
      
      // Room browser title
      let browserTitle = this.add.text(
        this.cameras.main.width / 2,
        this.cameras.main.height / 2 - 230, // More space at the top
        'ROOM BROWSER',
        {
          font: '32px Arial', // Slightly larger
          fill: '#ffffff',
          stroke: '#000000',
          strokeThickness: 4
        }
      ).setOrigin(0.5);
      
      // Room list container with metallic styling
      let roomListBg = this.add.rectangle(
        this.cameras.main.width / 2,
        this.cameras.main.height / 2 - 25, // Adjusted position
        600, 300, // Wider and taller
        0x222222
      ).setStrokeStyle(3, 0x666666);
      
      // Sample room entries (replace with actual room data)
      const roomData = [
        { name: "Alpha Squad", players: "5/10", ping: "45ms" },
        { name: "Bravo Team", players: "8/10", ping: "68ms" },
        { name: "Charlie Unit", players: "3/10", ping: "32ms" },
        { name: "Delta Force", players: "10/10", ping: "55ms" }
      ];
      
      // Column headers - positioned higher and wider apart
      let nameHeader = this.add.text(
        this.cameras.main.width / 2 - 260, // More space on the left
        this.cameras.main.height / 2 - 155,
        'SERVER NAME',
        { font: '18px Arial', fill: '#888888' }
      ).setOrigin(0, 0.5);
      
      let playersHeader = this.add.text(
        this.cameras.main.width / 2 + 50,
        this.cameras.main.height / 2 - 155,
        'PLAYERS',
        { font: '18px Arial', fill: '#888888' }
      ).setOrigin(0.5);
      
      let pingHeader = this.add.text(
        this.cameras.main.width / 2 + 150, // More space between columns
        this.cameras.main.height / 2 - 155,
        'PING',
        { font: '18px Arial', fill: '#888888' }
      ).setOrigin(0.5);
      
      // Create room entries with more vertical spacing
      let roomEntries = [];
      roomData.forEach((room, index) => {
        let y = this.cameras.main.height / 2 - 115 + (index * 65) + 10;

        if (index == 0) y = this.cameras.main.height / 2 - 115 + (10);
        
        // Room entry background - wider
        let entryBg = this.add.rectangle(
          this.cameras.main.width / 2,
          y,
          580, 60, // Larger for more padding
          index % 2 === 0 ? 0x444444 : 0x3a3a3a
        ).setStrokeStyle(1, 0x555555);
        
        // Room name - moved left
        let nameText = this.add.text(
          this.cameras.main.width / 2 - 250, // More space from the left edge
          y,
          room.name,
          { font: '20px Arial', fill: '#cccccc' } // Slightly larger font
        ).setOrigin(0, 0.5);
        
        // Player count
        let playersText = this.add.text(
          this.cameras.main.width / 2 + 50,
          y,
          room.players,
          { font: '20px Arial', fill: '#aaaaaa' } // Slightly larger font
        ).setOrigin(0.5);
        
        // Ping
        let pingText = this.add.text(
          this.cameras.main.width / 2 + 150, // More space between columns
          y,
          room.ping,
          { font: '20px Arial', fill: '#aaaaaa' } // Slightly larger font
        ).setOrigin(0.5);
        
        // Join button - moved right
        let joinButton = this.add.rectangle(
          this.cameras.main.width / 2 + 235, // More space from the right edge
          y,
          90, 40, // Larger button
          0x665533
        ).setStrokeStyle(2, 0x887755).setInteractive();
        
        let joinText = this.add.text(
          this.cameras.main.width / 2 + 235,
          y,
          'JOIN',
          { font: '20px Arial', fill: '#ffffff' } // Slightly larger font
        ).setOrigin(0.5);
        
        // Join button hover effect
        joinButton.on('pointerover', () => {
          joinButton.setFillStyle(0x776644);
        });
        joinButton.on('pointerout', () => {
          joinButton.setFillStyle(0x665533);
        });
        joinButton.on('pointerdown', () => {
          console.log(`Joining room: ${room.name}`);
          this.scene.start('MainScene');
        });
        
        roomEntries.push([entryBg, nameText, playersText, pingText, joinButton, joinText]);
      });
      
      // Refresh button - positioned better
      let refreshButton = this.add.rectangle(
        this.cameras.main.width / 2 + 270, // Aligned with JOIN buttons
        this.cameras.main.height / 2 - 155,
        30, 30, // Larger
        0x444444
      ).setStrokeStyle(2, 0x666666).setInteractive();
      
      let refreshIcon = this.add.text(
        this.cameras.main.width / 2 + 270,
        this.cameras.main.height / 2 - 155,
        '↻',
        { font: '24px Arial', fill: '#aaaaaa' } // Larger icon
      ).setOrigin(0.5);
      
      // Join code input - moved down for more space
      let codeInputBg = this.add.rectangle(
        this.cameras.main.width / 2 - 80,
        this.cameras.main.height / 2 + 180, // More space from the list
        300, 50, // Larger
        0x222222
      ).setStrokeStyle(2, 0x555555);
      
      let codeInputText = this.add.text(
        this.cameras.main.width / 2 - 215, // More space between label and field
        this.cameras.main.height / 2 + 180,
        'JOIN CODE:',
        { font: '20px Arial', fill: '#aaaaaa' } // Larger font
      ).setOrigin(0, 0.5);
      
      let joinCodeButton = this.add.rectangle(
        this.cameras.main.width / 2 + 150, // More space between input and button
        this.cameras.main.height / 2 + 180,
        90, 50, // Larger button
        0x665533
      ).setStrokeStyle(2, 0x887755).setInteractive();
      
      let joinCodeText = this.add.text(
        this.cameras.main.width / 2 + 150,
        this.cameras.main.height / 2 + 180,
        'JOIN',
        { font: '20px Arial', fill: '#ffffff' } // Larger font
      ).setOrigin(0.5);
      
      // Back button - moved down
      this.backButton = this.add.rectangle(
        this.cameras.main.width / 2,
        this.cameras.main.height / 2 + 240, // More space at the bottom
        150, 50, // Larger button
        0x333333
      ).setStrokeStyle(2, 0x666666).setInteractive();
      
      let backText = this.add.text(
        this.cameras.main.width / 2,
        this.cameras.main.height / 2 + 240,
        'BACK',
        { font: '22px Arial', fill: '#aaaaaa' } // Larger font
      ).setOrigin(0.5);
      
      // Button hover effects
      [joinCodeButton, refreshButton, this.backButton].forEach(button => {
        button.on('pointerover', () => {
          button.setFillStyle(button === joinCodeButton ? 0x776644 : 0x555555);
        });
        button.on('pointerout', () => {
          button.setFillStyle(button === joinCodeButton ? 0x665533 : 0x333333);
        });
      });
      
      // Button functionality
      refreshButton.on('pointerdown', () => {
        console.log('Refreshing server list');
        // Animation effect for refresh
        this.tweens.add({
          targets: refreshIcon,
          angle: 360,
          duration: 500,
          onComplete: () => {
            refreshIcon.angle = 0;
          }
        });
      });
      
      joinCodeButton.on('pointerdown', () => {
        console.log('Joining with code');
        this.scene.start('MainScene');
      });
      
      // Add everything to room browser container
      this.roomBrowser.add([
        darkOverlay, panelBg, browserTitle, roomListBg,
        nameHeader, playersHeader, pingHeader,
        codeInputBg, codeInputText, joinCodeButton, joinCodeText,
        refreshButton, refreshIcon,
        this.backButton, backText
      ]);
      
      // Flatten and add room entries
      roomEntries.forEach(entry => {
        entry.forEach(item => {
          this.roomBrowser.add(item);
        });
      });
    }
    
    toggleRoomBrowser(visible) {
      this.roomBrowserVisible = visible;
      this.roomBrowser.visible = visible;
      this.mainMenu.visible = !visible;
    }
  }
  
  export default StartScreen;
class Preloader extends Phaser.Scene {
    constructor() {
        super('Preloader');
    }

    preload() {
        console.log('Preloader Scene started');
        this.loadingText = this.add.text(this.cameras.main.width / 2, this.cameras.main.height / 2, 'Loading...', {
            font: '20px monospace',
            fill: '#ffffff'
        }).setOrigin(0.5);

        this.load.image('map_bg', 'assets/map_bg.png');
        this.load.image('map_col', 'assets/map_col.png');
        this.load.image('bg', 'assets/start_bg.png'); // A desaturated or blurred version of gameplay background
        this.load.image('logo', 'assets/game_logo.png'); // A sleek, minimal game logo
    }

    create() {
        console.log('Assets loaded');
        this.loadingText.destroy();
        this.scene.start('StartScreen');
    }
}

export default Preloader;
class MainScene extends Phaser.Scene {
    constructor() {
        super('MainScene');
    }

    preload() {
        // Load your game assets here (images, sounds, etc.)
        this.load.image('tiles', 'assets/map_bg.png'); // Example: loading your background image
    }

    create() {
        // Create your game objects and set up the scene here
        this.add.image(0, 0, 'tiles').setOrigin(0); // Example: adding the background
        this.cameras.main.setBounds(0, 0, 800, 600); // Example: setting camera bounds
    }

    update(time, delta) {
        // This function is called every frame
    }
}

export default MainScene;
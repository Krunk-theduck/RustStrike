import config from '../config/phaser_config.js';

window.onload = function() {
    window._pgame_ = new Phaser.Game(config);
};
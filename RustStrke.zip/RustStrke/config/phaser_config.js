import BootScene from '../src/scenes/BootScene.js';
import Preloader from '../src/scenes/Preloader.js';
import MainScene from '../src/scenes/MainScene.js';
import StartScreen from '../src/scenes/StartScreen.js';

const config = {
    type: Phaser.AUTO, // Use WebGL if available, otherwise Canvas
    width: window.innerWidth,
    height: window.innerHeight,
    parent: 'phaser-container', // Optional: ID of a div to put the canvas in
    scene: [BootScene, Preloader, StartScreen, MainScene],
    physics: {
        default: 'arcade', // You can choose a different physics engine if needed
        arcade: {
            gravity: { y: 0 }, // Top-down games usually don't have gravity
            debug: false     // Set to true to see physics bodies
        }
    },
    scale: {
        mode: Phaser.Scale.RESIZE, // Automatically handles resizing
        autoCenter: Phaser.Scale.CENTER_BOTH // Centers the game canvas in the window
    },
    // Add any other global Phaser configurations here
};

export default config;
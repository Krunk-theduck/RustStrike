/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_raycastengine_free: (a: number, b: number) => void;
export const raycastengine_new: (a: any) => number;
export const raycastengine_setAdaptiveRayCount: (a: number, b: number) => void;
export const raycastengine_precalculateTrigTables: (a: number) => void;
export const raycastengine_fastSin: (a: number, b: number) => number;
export const raycastengine_fastCos: (a: number, b: number) => number;
export const raycastengine_updateAdaptiveRayCount: (a: number) => void;
export const raycastengine_update: (a: number) => any;
export const raycastengine_castRays: (a: number, b: number, c: number, d: number) => void;
export const raycastengine_castSingleRay: (a: number, b: number, c: number, d: number) => void;
export const raycastengine_checkVisiblePlayers: (a: number, b: number, c: number, d: number) => void;
export const raycastengine_hasLineOfSight: (a: number, b: number, c: number, d: number, e: number) => number;
export const raycastengine_normalizeAngle: (a: number, b: number) => number;
export const raycastengine_initVisibilityMap: (a: number) => void;
export const raycastengine_setMaxDistance: (a: number, b: number) => void;
export const raycastengine_setRayCount: (a: number, b: number) => void;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_export_2: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_start: () => void;

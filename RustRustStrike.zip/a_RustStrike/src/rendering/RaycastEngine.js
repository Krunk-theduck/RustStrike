// Import the WASM module
import init, { RaycastEngine as RustRaycastEngine } from '../../public/wasm/raycast_engine.js';

// Original RaycastEngine implementation for fallback
// We'll keep the original class available in case WASM fails to load
window.OriginalRaycastEngine = window.RaycastEngine;

// Create a wrapper class that keeps the same interface
class RaycastEngineWrapper {
    constructor(game) {
        this.game = game;
        this.rustEngine = null;
        this.fallbackEngine = null;
        this.isWasmLoaded = false;
        this.isUsingFallback = false;
        
        // Initialize WASM
        this.initWasm();
    }
    
    async initWasm() {
        try {
            // Initialize WASM module
            await init();
            console.log('WASM RaycastEngine initialized');
            
            // Create Rust engine instance
            this.rustEngine = new RustRaycastEngine(this.game);
            this.isWasmLoaded = true;
        } catch (err) {
            console.error('Failed to initialize WASM RaycastEngine:', err);
            console.log('Falling back to JavaScript implementation');
            
            // Create fallback JS engine
            this.fallbackEngine = new window.OriginalRaycastEngine(this.game);
            this.isUsingFallback = true;
        }
    }
    
    // Proxy method to wait for WASM initialization
    async ensureEngine() {
        if (!this.isWasmLoaded && !this.isUsingFallback) {
            // Wait up to 2 seconds for WASM to load
            for (let i = 0; i < 20; i++) {
                await new Promise(resolve => setTimeout(resolve, 100));
                if (this.isWasmLoaded || this.isUsingFallback) break;
            }
            
            // If WASM still not loaded, use fallback
            if (!this.isWasmLoaded && !this.isUsingFallback) {
                console.warn('WASM loading timeout, switching to fallback');
                this.fallbackEngine = new window.OriginalRaycastEngine(this.game);
                this.isUsingFallback = true;
            }
        }
    }
    
    // Proxy all methods to the appropriate engine implementation
    async update() {
        await this.ensureEngine();
        return this.isUsingFallback ? this.fallbackEngine.update() : this.rustEngine.update();
    }
    
    setAdaptiveRayCount(enabled) {
        if (this.isUsingFallback) {
            this.fallbackEngine.setAdaptiveRayCount(enabled);
        } else if (this.isWasmLoaded) {
            this.rustEngine.setAdaptiveRayCount(enabled);
        }
    }
    
    precalculateTrigTables() {
        if (this.isUsingFallback) {
            this.fallbackEngine.precalculateTrigTables();
        } else if (this.isWasmLoaded) {
            this.rustEngine.precalculateTrigTables();
        }
    }
    
    fastSin(angle) {
        if (this.isUsingFallback) {
            return this.fallbackEngine.fastSin(angle);
        } else if (this.isWasmLoaded) {
            return this.rustEngine.fastSin(angle);
        }
        return Math.sin(angle); // Fallback
    }
    
    fastCos(angle) {
        if (this.isUsingFallback) {
            return this.fallbackEngine.fastCos(angle);
        } else if (this.isWasmLoaded) {
            return this.rustEngine.fastCos(angle);
        }
        return Math.cos(angle); // Fallback
    }
    
    updateAdaptiveRayCount() {
        if (this.isUsingFallback) {
            this.fallbackEngine.updateAdaptiveRayCount();
        } else if (this.isWasmLoaded) {
            this.rustEngine.updateAdaptiveRayCount();
        }
    }
    
    castRays(sourceX, sourceY, directionAngle) {
        if (this.isUsingFallback) {
            this.fallbackEngine.castRays(sourceX, sourceY, directionAngle);
        } else if (this.isWasmLoaded) {
            this.rustEngine.castRays(sourceX, sourceY, directionAngle);
        }
    }
    
    castSingleRay(sourceX, sourceY, angle) {
        if (this.isUsingFallback) {
            this.fallbackEngine.castSingleRay(sourceX, sourceY, angle);
        } else if (this.isWasmLoaded) {
            this.rustEngine.castSingleRay(sourceX, sourceY, angle);
        }
    }
    
    checkVisiblePlayers(sourceX, sourceY, directionAngle) {
        if (this.isUsingFallback) {
            this.fallbackEngine.checkVisiblePlayers(sourceX, sourceY, directionAngle);
        } else if (this.isWasmLoaded) {
            this.rustEngine.checkVisiblePlayers(sourceX, sourceY, directionAngle);
        }
    }
    
    hasLineOfSight(x1, y1, x2, y2) {
        if (this.isUsingFallback) {
            return this.fallbackEngine.hasLineOfSight(x1, y1, x2, y2);
        } else if (this.isWasmLoaded) {
            return this.rustEngine.hasLineOfSight(x1, y1, x2, y2);
        }
        return false; // Fallback
    }
    
    normalizeAngle(angle) {
        if (this.isUsingFallback) {
            return this.fallbackEngine.normalizeAngle(angle);
        } else if (this.isWasmLoaded) {
            return this.rustEngine.normalizeAngle(angle);
        }
        // Default implementation
        while (angle > Math.PI) angle -= 2 * Math.PI;
        while (angle < -Math.PI) angle += 2 * Math.PI;
        return angle;
    }
    
    initVisibilityMap() {
        if (this.isUsingFallback) {
            this.fallbackEngine.initVisibilityMap();
        } else if (this.isWasmLoaded) {
            this.rustEngine.initVisibilityMap();
        }
    }
    
    setMaxDistance(distance) {
        if (this.isUsingFallback) {
            this.fallbackEngine.setMaxDistance(distance);
        } else if (this.isWasmLoaded) {
            this.rustEngine.setMaxDistance(distance);
        }
    }
    
    setRayCount(count) {
        if (this.isUsingFallback) {
            this.fallbackEngine.setRayCount(count);
        } else if (this.isWasmLoaded) {
            this.rustEngine.setRayCount(count);
        }
    }
}

// Replace the original RaycastEngine with our wrapper
window.RaycastEngine = RaycastEngineWrapper;
export default RaycastEngineWrapper;
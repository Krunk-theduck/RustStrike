use std::collections::HashSet;
use wasm_bindgen::prelude::*;
use js_sys::{Array, Object, Reflect, Set};
use web_sys::{console, Performance};

// JavaScript Game and Map object interfaces
#[wasm_bindgen]
extern "C" {
    #[wasm_bindgen(js_namespace = window)]
    pub type Game;

    #[wasm_bindgen(method, getter)]
    pub fn localPlayer(this: &Game) -> Option<Player>;

    #[wasm_bindgen(method, getter)]
    pub fn map(this: &Game) -> Option<Map>;

    #[wasm_bindgen(method, getter)]
    pub fn players(this: &Game) -> Array;

    #[wasm_bindgen(js_namespace = window)]
    pub type Map;

    #[wasm_bindgen(method, getter)]
    pub fn tiles(this: &Map) -> Array;

    #[wasm_bindgen(method, getter)]
    pub fn tileSize(this: &Map) -> f32;

    #[wasm_bindgen(method, js_name = getTile)]
    pub fn get_tile(this: &Map, x: u32, y: u32) -> u32;

    #[wasm_bindgen(js_namespace = window)]
    pub type Player;

    #[wasm_bindgen(method, getter)]
    pub fn id(this: &Player) -> String;

    #[wasm_bindgen(method, getter)]
    pub fn x(this: &Player) -> f32;

    #[wasm_bindgen(method, getter)]
    pub fn y(this: &Player) -> f32;

    #[wasm_bindgen(method, getter)]
    pub fn aim(this: &Player) -> Object;

    #[wasm_bindgen(method, getter, js_name = isAlive)]
    pub fn is_alive(this: &Player) -> bool;
}

#[wasm_bindgen]
pub struct RaycastEngine {
    game: Game,
    max_distance: f32,
    ray_count: u32,
    fov_angle: f32,
    adaptive_ray_count: bool,
    performance_stats: PerformanceStats,
    visible_tiles: HashSet<String>,
    visible_players: HashSet<String>,
    last_update_time: f64,
    update_interval: f64,
    sin_table: Vec<f32>,
    cos_table: Vec<f32>,
    last_results: Option<Object>,
}

struct PerformanceStats {
    last_frame_time: f64,
    frame_times: Vec<f64>,
    avg_frame_time: f64,
}

#[wasm_bindgen]
impl RaycastEngine {
    #[wasm_bindgen(constructor)]
    pub fn new(game: Game) -> Self {
        console::log_1(&"Initializing Rust RaycastEngine".into());
        
        let mut engine = RaycastEngine {
            game,
            max_distance: 700.0,
            ray_count: 120,
            fov_angle: std::f32::consts::PI * 80.0 / 180.0,
            adaptive_ray_count: true,
            performance_stats: PerformanceStats {
                last_frame_time: 0.0,
                frame_times: Vec::new(),
                avg_frame_time: 0.0,
            },
            visible_tiles: HashSet::new(),
            visible_players: HashSet::new(),
            last_update_time: 0.0,
            update_interval: 50.0,
            sin_table: Vec::new(),
            cos_table: Vec::new(),
            last_results: None,
        };
        
        engine.precalculate_trig_tables();
        engine
    }
    
    #[wasm_bindgen(js_name = setAdaptiveRayCount)]
    pub fn set_adaptive_ray_count(&mut self, enabled: bool) {
        self.adaptive_ray_count = enabled;
        
        // Reset performance stats
        self.performance_stats = PerformanceStats {
            last_frame_time: 0.0,
            frame_times: Vec::new(),
            avg_frame_time: 0.0,
        };
    }
    
    #[wasm_bindgen(js_name = precalculateTrigTables)]
    pub fn precalculate_trig_tables(&mut self) {
        let precision = 1000;
        self.sin_table = Vec::with_capacity(precision);
        self.cos_table = Vec::with_capacity(precision);
        
        for i in 0..precision {
            let angle = (i as f32 / precision as f32) * (2.0 * std::f32::consts::PI);
            self.sin_table.push(angle.sin());
            self.cos_table.push(angle.cos());
        }
    }
    
    #[wasm_bindgen(js_name = fastSin)]
    pub fn fast_sin(&self, angle: f32) -> f32 {
        // Normalize angle to [0, 2π]
        let mut normalized_angle = angle;
        while normalized_angle < 0.0 {
            normalized_angle += 2.0 * std::f32::consts::PI;
        }
        while normalized_angle >= 2.0 * std::f32::consts::PI {
            normalized_angle -= 2.0 * std::f32::consts::PI;
        }
        
        // Get index in lookup table
        let table_len = self.sin_table.len();
        let index = ((normalized_angle / (2.0 * std::f32::consts::PI)) 
                    * table_len as f32).floor() as usize % table_len;
        self.sin_table[index]
    }
    
    #[wasm_bindgen(js_name = fastCos)]
    pub fn fast_cos(&self, angle: f32) -> f32 {
        // Normalize angle to [0, 2π]
        let mut normalized_angle = angle;
        while normalized_angle < 0.0 {
            normalized_angle += 2.0 * std::f32::consts::PI;
        }
        while normalized_angle >= 2.0 * std::f32::consts::PI {
            normalized_angle -= 2.0 * std::f32::consts::PI;
        }
        
        // Get index in lookup table
        let table_len = self.cos_table.len();
        let index = ((normalized_angle / (2.0 * std::f32::consts::PI)) 
                    * table_len as f32).floor() as usize % table_len;
        self.cos_table[index]
    }
    
    #[wasm_bindgen(js_name = updateAdaptiveRayCount)]
    pub fn update_adaptive_ray_count(&mut self) {
        if !self.adaptive_ray_count {
            return;
        }
        
        let frame_time = self.performance_stats.avg_frame_time;
        let target_frame_time = 8.0; // Target 8ms per raycast
        
        if frame_time > target_frame_time * 1.2 {
            // Too slow
            self.ray_count = (self.ray_count as f64 * 0.9) as u32;
            self.ray_count = self.ray_count.max(60);
        } else if frame_time < target_frame_time * 0.8 {
            // Too fast
            self.ray_count = (self.ray_count as f64 * 1.1) as u32;
            self.ray_count = self.ray_count.min(360);
        }
    }
    
    #[wasm_bindgen]
    pub fn update(&mut self) -> Option<Object> {
        // Get current time and performance
        let window = web_sys::window().expect("should have a window");
        let performance = window.performance().expect("performance should be available");
        let now = performance.now();
        let start_time = now;
        
        // Only update periodically for performance
        if now - self.last_update_time < self.update_interval {
            return self.last_results.clone();
        }
        
        self.last_update_time = now;
        
        // Get local player
        let player = match self.game.localPlayer() {
            Some(p) => p,
            None => return None,
        };
        
        // Reset visibility data
        self.visible_tiles.clear();
        self.visible_players.clear();
        
        // Get player direction angle
        let aim = player.aim();
        let direction_angle = Reflect::get(&aim, &"angle".into())
            .ok()
            .and_then(|v| v.as_f64())
            .unwrap_or(0.0) as f32;
        
        // Cast rays
        self.cast_rays(player.x(), player.y(), direction_angle);
        
        // Check visible players
        self.check_visible_players(player.x(), player.y(), direction_angle);
        
        // Track performance
        let end_time = performance.now();
        let frame_time = end_time - start_time;
        
        self.performance_stats.frame_times.push(frame_time);
        if self.performance_stats.frame_times.len() > 30 {
            self.performance_stats.frame_times.remove(0);
        }
        
        // Calculate average frame time
        let sum: f64 = self.performance_stats.frame_times.iter().sum();
        self.performance_stats.avg_frame_time = sum / self.performance_stats.frame_times.len() as f64;
        
        // Update ray count based on performance
        self.update_adaptive_ray_count();
        
        // Create result object
        let result = Object::new();
        
        // Convert visible tiles to JS Set
        let visible_tiles_set = Set::new(&JsValue::NULL);
        for coord in &self.visible_tiles {
            visible_tiles_set.add(&JsValue::from_str(coord));
        }
        Reflect::set(&result, &"visibleTiles".into(), &visible_tiles_set.into()).unwrap();
        
        // Convert visible players to JS Set
        let visible_players_set = Set::new(&JsValue::NULL);
        for id in &self.visible_players {
            visible_players_set.add(&JsValue::from_str(id));
        }
        Reflect::set(&result, &"visiblePlayers".into(), &visible_players_set.into()).unwrap();
        
        // Add other properties
        Reflect::set(&result, &"rayCount".into(), &JsValue::from(self.ray_count)).unwrap();
        
        // Add performance data
        let perf = Object::new();
        Reflect::set(&perf, &"frameTime".into(), &JsValue::from(frame_time)).unwrap();
        Reflect::set(&perf, &"avgFrameTime".into(), &JsValue::from(self.performance_stats.avg_frame_time)).unwrap();
        Reflect::set(&result, &"performance".into(), &perf).unwrap();
        
        self.last_results = Some(result.clone());
        Some(result)
    }
    
    #[wasm_bindgen(js_name = castRays)]
    pub fn cast_rays(&mut self, source_x: f32, source_y: f32, direction_angle: f32) {
        let map = match self.game.map() {
            Some(m) => m,
            None => return,
        };
        
        if map.tiles().length() == 0 {
            return;
        }
        
        // Calculate start and end angles based on FOV
        let start_angle = direction_angle - self.fov_angle / 2.0;
        let end_angle = direction_angle + self.fov_angle / 2.0;
        let angle_step = self.fov_angle / self.ray_count as f32;
        
        // Mark player's position as visible
        let tile_size = map.tileSize();
        let player_tile_x = (source_x / tile_size).floor() as i32;
        let player_tile_y = (source_y / tile_size).floor() as i32;
        self.visible_tiles.insert(format!("{},{}", player_tile_x, player_tile_y));
        
        // Cast rays at different angles within FOV
        let mut angle = start_angle;
        while angle <= end_angle {
            self.cast_single_ray(source_x, source_y, angle);
            angle += angle_step;
        }
    }
    
    #[wasm_bindgen(js_name = castSingleRay)]
    pub fn cast_single_ray(&mut self, source_x: f32, source_y: f32, angle: f32) {
        let map = match self.game.map() {
            Some(m) => m,
            None => return,
        };
        
        let tile_size = map.tileSize();
        
        // Get direction vector
        let dir_x = self.fast_cos(angle);
        let dir_y = self.fast_sin(angle);
        
        // Current position in tiles
        let mut tile_x = (source_x / tile_size).floor() as i32;
        let mut tile_y = (source_y / tile_size).floor() as i32;
        
        // Distance to next tile boundary
        let mut step_x = 0;
        let mut step_y = 0;
        let mut dist_to_next_x = 0.0;
        let mut dist_to_next_y = 0.0;
        
        // Calculate step and initial distance to tile boundary
        if dir_x > 0.0 {
            step_x = 1;
            dist_to_next_x = ((tile_x + 1) as f32 * tile_size - source_x) / dir_x;
        } else if dir_x < 0.0 {
            step_x = -1;
            dist_to_next_x = (tile_x as f32 * tile_size - source_x) / dir_x;
        } else {
            dist_to_next_x = f32::INFINITY;
        }
        
        if dir_y > 0.0 {
            step_y = 1;
            dist_to_next_y = ((tile_y + 1) as f32 * tile_size - source_y) / dir_y;
        } else if dir_y < 0.0 {
            step_y = -1;
            dist_to_next_y = (tile_y as f32 * tile_size - source_y) / dir_y;
        } else {
            dist_to_next_y = f32::INFINITY;
        }
        
        // Distance traveled
        let mut distance = 0.0;
        let mut hit_wall = false;
        
        // Get map dimensions
        let map_rows = map.tiles().length() as i32;
        let map_cols = if map_rows > 0 {
            Reflect::get_u32(&map.tiles(), 0)
                .ok()
                .and_then(|row| Some(Array::from(&row).length() as i32))
                .unwrap_or(0)
        } else {
            0
        };
        
        // Digital Differential Analysis (DDA) algorithm
        while distance < self.max_distance && !hit_wall {
            // Add current tile to visible tiles
            if tile_x >= 0 && tile_x < map_cols && tile_y >= 0 && tile_y < map_rows {
                self.visible_tiles.insert(format!("{},{}", tile_x, tile_y));
            }
            
            // Check if current tile is a wall
            if tile_x >= 0 && tile_x < map_cols && tile_y >= 0 && tile_y < map_rows {
                if map.get_tile(tile_x as u32, tile_y as u32) == 1 {
                    hit_wall = true;
                    break;
                }
            }
            
            // Move to next tile
            if dist_to_next_x < dist_to_next_y {
                distance = dist_to_next_x;
                dist_to_next_x += tile_size / dir_x.abs();
                tile_x += step_x;
            } else {
                distance = dist_to_next_y;
                dist_to_next_y += tile_size / dir_y.abs();
                tile_y += step_y;
            }
        }
    }
    
    #[wasm_bindgen(js_name = checkVisiblePlayers)]
    pub fn check_visible_players(&mut self, source_x: f32, source_y: f32, direction_angle: f32) {
        let local_player = match self.game.localPlayer() {
            Some(p) => p,
            None => return,
        };
        
        let players = self.game.players();
        let len = players.length();
        
        for i in 0..len {
            if let Some(other_player) = players.get(i).dyn_into::<Player>().ok() {
                if other_player.id() == local_player.id() || !other_player.is_alive() {
                    continue;
                }
                
                // Calculate angle to other player
                let dx = other_player.x() - source_x;
                let dy = other_player.y() - source_y;
                let distance = (dx * dx + dy * dy).sqrt();
                
                // Skip if too far away
                if distance > self.max_distance {
                    continue;
                }
                
                // Check if player is within FOV
                let angle = dy.atan2(dx);
                let angle_diff = self.normalize_angle(angle - direction_angle).abs();
                
                if angle_diff > self.fov_angle / 2.0 {
                    continue;
                }
                
                // Check line of sight
                if self.has_line_of_sight(source_x, source_y, other_player.x(), other_player.y()) {
                    self.visible_players.insert(other_player.id());
                }
            }
        }
    }
    
    #[wasm_bindgen(js_name = hasLineOfSight)]
    pub fn has_line_of_sight(&self, x1: f32, y1: f32, x2: f32, y2: f32) -> bool {
        let map = match self.game.map() {
            Some(m) => m,
            None => return false,
        };
        
        let tile_size = map.tileSize();
        
        // Optimize by using only a few points instead of tracing the entire line
        let dx = x2 - x1;
        let dy = y2 - y1;
        let distance = (dx * dx + dy * dy).sqrt();
        
        // Number of samples depends on distance
        let num_samples = (distance / tile_size).ceil().min(10.0) as u32;
        
        // Get map dimensions
        let map_rows = map.tiles().length() as i32;
        let map_cols = if map_rows > 0 {
            Reflect::get_u32(&map.tiles(), 0)
                .ok()
                .and_then(|row| Some(Array::from(&row).length() as i32))
                .unwrap_or(0)
        } else {
            0
        };
        
        for i in 0..=num_samples {
            let t = i as f32 / num_samples as f32;
            let x = x1 + dx * t;
            let y = y1 + dy * t;
            
            let tile_x = (x / tile_size).floor() as i32;
            let tile_y = (y / tile_size).floor() as i32;
            
            // Check if out of bounds
            if tile_x < 0 || tile_x >= map_cols || tile_y < 0 || tile_y >= map_rows {
                return false;
            }
            
            // Check if we hit a wall
            if map.get_tile(tile_x as u32, tile_y as u32) == 1 {
                return false;
            }
        }
        
        true
    }
    
    #[wasm_bindgen(js_name = normalizeAngle)]
    pub fn normalize_angle(&self, angle: f32) -> f32 {
        // Normalize angle to range [-PI, PI]
        let mut result = angle;
        while result > std::f32::consts::PI {
            result -= 2.0 * std::f32::consts::PI;
        }
        while result < -std::f32::consts::PI {
            result += 2.0 * std::f32::consts::PI;
        }
        result
    }
    
    #[wasm_bindgen(js_name = initVisibilityMap)]
    pub fn init_visibility_map(&mut self) {
        // Reset visibility data
        self.visible_tiles.clear();
        self.visible_players.clear();
        
        // Force update on next game loop
        self.last_update_time = 0.0;
        
        console::log_1(&"Visibility map reinitialized".into());
    }
    
    #[wasm_bindgen(js_name = setMaxDistance)]
    pub fn set_max_distance(&mut self, distance: f32) {
        self.max_distance = distance;
        // Reset visibility map when changing max distance
        self.init_visibility_map();
    }
    
    #[wasm_bindgen(js_name = setRayCount)]
    pub fn set_ray_count(&mut self, count: u32) {
        self.ray_count = count;
        // Reset visibility map when changing ray count
        self.init_visibility_map();
    }
}
import { database } from './firebase-config.js';

export class RoomManager {
    constructor(game) {
        this.game = game;
        this.database = database;
        this.activeRoom = null;
        this.roomListeners = new Map();
        this.setupConnectionMonitoring();
    }

    setupConnectionMonitoring() {
        const connectedRef = this.database.ref('.info/connected');
        connectedRef.on('value', (snap) => {
            if (snap.val() === true && this.activeRoom) {
                this.setupDisconnectHandlers();
            }
        });
    }

    setupDisconnectHandlers() {
        if (!this.activeRoom) return;

        const roomRef = this.database.ref(`rooms/${this.activeRoom}`);
        const playerRef = roomRef.child(`players/${this.game.localPlayer.id}`);
        const hostRef = roomRef.child('hostId');

        // Set up disconnect cleanup
        playerRef.onDisconnect().remove();

        // Check if user is host
        hostRef.get().then((snapshot) => {
            if (snapshot.val() === this.game.localPlayer.id) {
                roomRef.onDisconnect().remove();
            }
        });
    }

    async createRoom(roomCode) {
        try {
            // Clear any existing room connection
            await this.leaveRoom();

            const roomRef = this.database.ref(`rooms/${roomCode}`);
            const roomData = {
                hostId: this.game.localPlayer.id,
                map: this.game.map.tiles,
                players: {
                    [this.game.localPlayer.id]: {
                        x: this.game.localPlayer.x,
                        y: this.game.localPlayer.y,
                        id: this.game.localPlayer.id
                    }
                },
                createdAt: window.ServerValue.TIMESTAMP
            };

            await roomRef.set(roomData);
            this.activeRoom = roomCode;
            this.listenToRoom(roomCode);
            this.setupDisconnectHandlers();

            return roomCode;
        } catch (error) {
            console.error('Error creating room:', error);
            throw error;
        }
    }

    async joinRoom(roomCode) {
        try {
            // Clear any existing room connection
            await this.leaveRoom();

            const roomRef = this.database.ref(`rooms/${roomCode}`);
            const snapshot = await roomRef.once('value');
            const roomData = snapshot.val();

            if (!roomData) {
                throw new Error('Room not found');
            }

            // Add player to room
            await roomRef.child('players').update({
                [this.game.localPlayer.id]: {
                    x: this.game.localPlayer.x,
                    y: this.game.localPlayer.y,
                    id: this.game.localPlayer.id
                }
            });

            // Load map data
            this.game.map.tiles = roomData.map;

            this.activeRoom = roomCode;
            this.listenToRoom(roomCode);
            this.setupDisconnectHandlers();

            return roomCode;
        } catch (error) {
            console.error('Error joining room:', error);
            throw error;
        }
    }

    listenToRoom(roomCode) {
        if (this.roomListeners.has(roomCode)) return;

        const playersRef = this.database.ref(`rooms/${roomCode}/players`);
        const listener = playersRef.on('value', (snapshot) => {
            const players = snapshot.val() || {};

            // Remove disconnected players
            for (const [playerId, player] of this.game.players) {
                if (!players[playerId] && playerId !== this.game.localPlayer.id) {
                    this.game.players.delete(playerId);
                }
            }

            // Update or add players
            for (const [playerId, playerData] of Object.entries(players)) {
                if (playerId === this.game.localPlayer.id) continue;

                let player = this.game.players.get(playerId);
                if (!player) {
                    // Use the global Player class
                    player = new window.Player(playerData.x, playerData.y);
                    player.id = playerId;
                    this.game.players.set(playerId, player);
                } else {
                    player.x = playerData.x;
                    player.y = playerData.y;
                }
            }
        });

        this.roomListeners.set(roomCode, listener);
    }

    async leaveRoom() {
        if (!this.activeRoom) return;

        try {
            const roomRef = this.database.ref(`rooms/${this.activeRoom}`);
            const playerRef = roomRef.child(`players/${this.game.localPlayer.id}`);
            
            // Cancel all onDisconnect operations
            await roomRef.onDisconnect().cancel();
            await playerRef.onDisconnect().cancel();

            // Remove player from room
            await playerRef.remove();

            // Clean up listeners
            if (this.roomListeners.has(this.activeRoom)) {
                roomRef.off('value', this.roomListeners.get(this.activeRoom));
                this.roomListeners.delete(this.activeRoom);
            }

            this.activeRoom = null;
        } catch (error) {
            console.error('Error leaving room:', error);
        }
    }
}

// Make RoomManager globally available
window.RoomManager = RoomManager; 
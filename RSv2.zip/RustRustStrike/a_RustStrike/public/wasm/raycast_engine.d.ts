/* tslint:disable */
/* eslint-disable */
export class RaycastEngine {
  free(): void;
  constructor(game: any);
  setAdaptiveRayCount(enabled: boolean): void;
  precalculateTrigTables(): void;
  fastSin(angle: number): number;
  fastCos(angle: number): number;
  updateAdaptiveRayCount(): void;
  update(): object | undefined;
  castRays(source_x: number, source_y: number, direction_angle: number): void;
  castSingleRay(source_x: number, source_y: number, angle: number): void;
  checkVisiblePlayers(source_x: number, source_y: number, direction_angle: number): void;
  hasLineOfSight(x1: number, y1: number, x2: number, y2: number): boolean;
  normalizeAngle(angle: number): number;
  initVisibilityMap(): void;
  setMaxDistance(distance: number): void;
  setRayCount(count: number): void;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_raycastengine_free: (a: number, b: number) => void;
  readonly raycastengine_new: (a: any) => number;
  readonly raycastengine_setAdaptiveRayCount: (a: number, b: number) => void;
  readonly raycastengine_precalculateTrigTables: (a: number) => void;
  readonly raycastengine_fastSin: (a: number, b: number) => number;
  readonly raycastengine_fastCos: (a: number, b: number) => number;
  readonly raycastengine_updateAdaptiveRayCount: (a: number) => void;
  readonly raycastengine_update: (a: number) => any;
  readonly raycastengine_castRays: (a: number, b: number, c: number, d: number) => void;
  readonly raycastengine_castSingleRay: (a: number, b: number, c: number, d: number) => void;
  readonly raycastengine_checkVisiblePlayers: (a: number, b: number, c: number, d: number) => void;
  readonly raycastengine_hasLineOfSight: (a: number, b: number, c: number, d: number, e: number) => number;
  readonly raycastengine_normalizeAngle: (a: number, b: number) => number;
  readonly raycastengine_initVisibilityMap: (a: number) => void;
  readonly raycastengine_setMaxDistance: (a: number, b: number) => void;
  readonly raycastengine_setRayCount: (a: number, b: number) => void;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_export_2: WebAssembly.Table;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;

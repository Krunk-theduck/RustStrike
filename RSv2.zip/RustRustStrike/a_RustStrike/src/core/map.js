export class Map {
    constructor() {
        this.tileSize = 32; // pixels per tile
        this.isLoaded = false; // Track loading state
        
        // Initialize team spawns
        this.teamSpawns = {
            red: { x: 0, y: 0 },
            blue: { x: 0, y: 0 }
        };
        
        // Room references (will be set based on map decorations)
        this.rooms = {
            redSpawn: null,
            blueSpawn: null,
            center: null,
            bombSite: null
        };
        
        // Initialize with empty arrays to prevent undefined errors
        this.tiles = [[0]]; // Minimum valid array
        this.decorations = [[null]];
        
        // Start loading the map
        this.loadMap();
    }

    async loadMap() {
            // Load collision map
            this.collisionData = await this.loadCollisionMap('../../public/map_col.png');
            
            // Assign tiles from collision data
            this.tiles = this.collisionData.map(row => row.slice());
            console.log(this.tiles)
            
            // Initialize decorations
            this.decorations = Array(this.tiles.length).fill().map(() => 
                Array(this.tiles[0].length).fill(null)
            );
            
            // Identify special areas and decorations
            this.identifyMapAreas();
            
            // Load background image
            this.backgroundImage = new Image();
            this.backgroundImage.src = '../../public/map_bg.png';
            
            // Mark as loaded
            this.isLoaded = true;
            console.log("Map loaded successfully!");
    }

    async loadCollisionMap(imagePath) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                
                canvas.width = img.width;
                canvas.height = img.height;
                ctx.drawImage(img, 0, 0);
                
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                const data = imageData.data;
                
                // Create array based on the image dimensions
                // Ensure at least one tile per pixel, but maintain tileSize for calculations
                const mapWidth = Math.max(1, Math.floor(img.width));
                const mapHeight = Math.max(1, Math.floor(img.height));
                const collisionMap = Array(mapHeight).fill().map(() => Array(mapWidth).fill(0));
                
                // Process the image - black pixels (collision) = 1, transparent = 0
                for (let y = 0; y < mapHeight; y++) {
                    for (let x = 0; x < mapWidth; x++) {
                        // Sample the center of each tile
                        const pixelX = Math.floor(x * 6 + this.tileSize / 2);
                        const pixelY = Math.floor(y * 6 + this.tileSize / 2);
                        
                        if (pixelX >= img.width || pixelY >= img.height) {
                            collisionMap[y][x] = 1; // Wall for out of bounds
                            continue;
                        }
                        
                        // Calculate index in the pixel data array
                        const idx = (pixelY * img.width + pixelX) * 4;
                        
                        // Check if pixel is black (or close to black) and not transparent
                        const r = data[idx];
                        const g = data[idx + 1];
                        const b = data[idx + 2];
                        const a = data[idx + 3];
                        
                        // If alpha is low or the color is not black, it's walkable (0), otherwise collision (1)
                        if (a < 128 || (r > 30 && g > 30 && b > 30)) {
                            collisionMap[y][x] = 0; // Walkable
                        } else {
                            collisionMap[y][x] = 1; // Collision
                        }
                    }
                }
                
                resolve(collisionMap);
            };
            
            img.onerror = () => {
                console.error(`Failed to load map image: ${imagePath}`);
                reject(new Error(`Failed to load map image: ${imagePath}`));
            };
            
            img.src = imagePath;
        });
    }

    identifyMapAreas() {
        if (!this.tiles || !this.tiles.length || !this.tiles[0].length) {
            console.error("Cannot identify map areas: tiles not initialized");
            return;
        }
        
        const width = this.tiles[0].length;
        const height = this.tiles.length;
        
        // Red team spawn (example: top-left quarter)
        const redSpawnX = Math.floor(width * 0.125);
        const redSpawnY = Math.floor(height * 0.125);
        this.teamSpawns.red = {
            x: 1,
            y: 5
        };
        
        // Create red spawn room area
        this.rooms.redSpawn = {
            x: Math.floor(width * 0.05),
            y: Math.floor(height * 0.05),
            width: Math.floor(width * 0.15),
            height: Math.floor(height * 0.15)
        };
        
        // Blue team spawn (example: bottom-right quarter)
        const blueSpawnX = Math.floor(width * 0.875);
        const blueSpawnY = Math.floor(height * 0.875);
        this.teamSpawns.blue = {
            x: blueSpawnX * this.tileSize,
            y: blueSpawnY * this.tileSize
        };
        
        // Create blue spawn room area
        this.rooms.blueSpawn = {
            x: Math.floor(width * 0.8),
            y: Math.floor(height * 0.8),
            width: Math.floor(width * 0.15),
            height: Math.floor(height * 0.15)
        };
        
        // Center room
        this.rooms.center = {
            x: Math.floor(width * 0.4),
            y: Math.floor(height * 0.4),
            width: Math.floor(width * 0.2),
            height: Math.floor(height * 0.2)
        };
        
        // Bomb site (example: near red spawn)
        this.rooms.bombSite = {
            x: Math.floor(width * 0.25),
            y: Math.floor(height * 0.25),
            width: Math.floor(width * 0.2),
            height: Math.floor(height * 0.2)
        };
        
        // Decorate the rooms
        this.decorateRoom(this.rooms.redSpawn, 'red');
        this.decorateRoom(this.rooms.blueSpawn, 'blue');
        this.decorateRoom(this.rooms.bombSite, 'bombsite');
    }

    getTile(x, y) {
        if (!this.tiles || !this.tiles.length || !this.tiles[0]) {
            return 1; // Default to wall if tiles aren't loaded yet
        }
        
        if (x < 0 || x >= this.tiles[0].length || y < 0 || y >= this.tiles.length) {
            return 1; // Return wall for out of bounds
        }
        return this.tiles[y][x];
    }

    isWalkable(x, y) {
        // Convert to tile coordinates
        const tileX = Math.floor(x / this.tileSize);
        const tileY = Math.floor(y / this.tileSize);
        
        // Check if map is loaded and coordinates are valid
        if (!this.tiles || !this.tiles.length || !this.tiles[0]) {
            return false; // Default to unwalkable if tiles aren't loaded yet
        }
        
        // Check bounds
        if (tileX < 0 || tileX >= this.tiles[0].length || tileY < 0 || tileY >= this.tiles.length) {
            return false; // Out of bounds
        }
        
        // In our new system, 0 is walkable, 1 is collision
        return this.tiles[tileY][tileX] === 0;
    }

    getSpawnPoint(team) {
        if (team === 'red' || team === 'blue') {
            // Get the base spawn point for the team
            const spawnPoint = this.teamSpawns[team];
            
            // Add a small random offset within the spawn area (2 tiles in any direction)
            const offsetX = (Math.random() * 2 - 1) * this.tileSize * 2;
            const offsetY = (Math.random() * 2 - 1) * this.tileSize * 2;
            
            const finalSpawn = {
                x: spawnPoint.x + offsetX,
                y: spawnPoint.y + offsetY
            };

            // Make sure the spawn point is walkable
            if (this.isWalkable(finalSpawn.x, finalSpawn.y)) {
                return finalSpawn;
            } else {
                // If not walkable, return the base spawn point
                return spawnPoint;
            }
        }
        
        // For neutral/spectator, return center of map
        if (!this.tiles || !this.tiles.length || !this.tiles[0]) {
            return { x: 0, y: 0 }; // Default if map not loaded
        }
        
        const centerSpawn = {
            x: (this.tiles[0].length / 2) * this.tileSize,
            y: (this.tiles.length / 2) * this.tileSize
        };
        return centerSpawn;
    }

    decorateRoom(room, decoration) {
        if (!room || !this.decorations || !this.decorations.length) return;
        
        for (let y = room.y; y < room.y + room.height; y++) {
            for (let x = room.x; x < room.x + room.width; x++) {
                if (y >= 0 && y < this.decorations.length && 
                    x >= 0 && x < this.decorations[0].length) {
                    this.decorations[y][x] = decoration;
                }
            }
        }
    }

    getDecoration(x, y) {
        // Convert to tile coordinates
        const tileX = Math.floor(x / this.tileSize);
        const tileY = Math.floor(y / this.tileSize);
        
        if (!this.decorations || !this.decorations.length || !this.decorations[0] ||
            tileX < 0 || tileX >= this.decorations[0].length || 
            tileY < 0 || tileY >= this.decorations.length) {
            return null;
        }
        return this.decorations[tileY][tileX];
    }

    isInBombSite(x, y) {
        return this.getDecoration(x, y) === 'bombsite';
    }

    // Method to check if map is ready to use
    isReady() {
        return this.isLoaded;
    }

    // Additional method to render the background (optional)
    renderBackground(ctx) {
        if (this.backgroundImage && this.backgroundImage.complete) {
            ctx.drawImage(this.backgroundImage, 0, 0);
        }
    }
}

// Make Map globally available as GameMap to avoid conflicts with built-in Map
window.GameMap = Map;
/**
 * UIEffects.js - Handles the visual and audio effects for the UI
 */

class UIEffects {
    constructor() {  
        
        // Setup button effects
        this.setupButtonEffects();
        
        // Generate particles
        this.generateParticles();
        
        // Setup glitch effect on title
        this.setupGlitchEffect();
        
        // Handle screen transitions
        this.setupScreenTransitions();
    }
    
    // Setup ripple effect and sounds for buttons
    setupButtonEffects() {
        const buttons = document.querySelectorAll('.menu-button, .back-button, .join-option-button');
        
        buttons.forEach(button => {
            
            button.addEventListener('mouseenter', () => {
                button.style.transform = 'scale(1.05)';
            });
            
            button.addEventListener('mouseleave', () => {
                button.style.transform = 'scale(1)';
            });
        });
    }
    
    // Create ripple effect on button click
    createRipple(event) {
        const button = event.currentTarget;
        const circle = document.createElement('span');
        circle.classList.add('ripple');
        
        const rect = button.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = event.clientX - rect.left - size / 2;
        const y = event.clientY - rect.top - size / 2;
        
        circle.style.width = circle.style.height = `${size}px`;
        circle.style.left = `${x}px`;
        circle.style.top = `${y}px`;
        
        button.appendChild(circle);
        
        setTimeout(() => {
            circle.remove();
        }, 600);
    }
    
    // Placeholder for particle effects
    generateParticles() {
        console.log("Particles effect initialized");
    }
    
    // Placeholder for glitch effect
    setupGlitchEffect() {
        console.log("Glitch effect initialized");
    }
    
    // Placeholder for screen transitions
    setupScreenTransitions() {
        console.log("Screen transitions initialized");
    }
}

// Initialize the UI effects when the page loads
document.addEventListener("DOMContentLoaded", () => new UIEffects());
